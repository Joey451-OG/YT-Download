This document is a copy of README.md from Git.

The SOURCE CODE directory contains a copy of 'main.py' and 'YT Download.py' for GitHub.

~~~~~BEGINING OF README.md~~~~~
# YT-Dowload
A portable yt-dlp wrapper with GUI

## Credits
Icon: Image by https://pixabay.com/images/id-1834016/

Dependencies:

YT-DLP: https://github.com/yt-dlp/yt-dlp

PySimpleGUI: https://github.com/PySimpleGUI/PySimpleGUI

FFmpeg: https://ffmpeg.org/

Thank you for using YT Download!

